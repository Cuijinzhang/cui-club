import com.cui.core.core.CodeGenerationCode;

public class GenCodeMain {

    public static void main(String[] args) {
        CodeGenerationCode.doGenCode(new BizPutContextHandler());
    }

}
