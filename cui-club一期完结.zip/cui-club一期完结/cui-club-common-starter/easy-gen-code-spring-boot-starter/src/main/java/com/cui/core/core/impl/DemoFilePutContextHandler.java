package com.cui.core.core.impl;

import com.cui.core.core.sdk.FilePutContextHandler;

import java.util.Map;

public class DemoFilePutContextHandler implements FilePutContextHandler {

    @Override
    public Map<String, Object> putData(String fileId) {
        return null;
    }

}
