package com.cui.core.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * 集合类
 *
 * @author loser
 * @date 2023/9/4
 */
public class Lists {

    public static List<Object> newArrayList() {
        return new ArrayList<>();
    }

}
