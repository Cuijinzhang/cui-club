package com.cui.auth.domain.constants;

/**
 * auth服务常量
 *
 * @author: ChickenWing
 * @date: 2023/11/3
 */
public class AuthConstant {

    public static final String NORMAL_USER = "normal_user";

}
